package lf.ot;

import org.bukkit.plugin.java.*;
import org.bukkit.event.*;
import com.earth2me.essentials.*;
import org.bukkit.plugin.*;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import java.util.*;
import org.bukkit.*;

public class Main extends JavaPlugin implements Listener
{
    private static Essentials ess;
    
    public void onEnable() {
        final Plugin essentialsPlugin = Bukkit.getPluginManager().getPlugin("Essentials");
        Main.ess = (Essentials)Bukkit.getServer().getPluginManager().getPlugin("Essentials");
        Bukkit.getServer().getPluginManager().registerEvents((Listener)this, (Plugin)this);
        if (essentialsPlugin == null) {
            Bukkit.getConsoleSender().sendMessage("§cEssentials 没有发现插件已卸载...!");
            Bukkit.getPluginManager().disablePlugin((Plugin)this);
            return;
        }
        Bukkit.getConsoleSender().sendMessage("§a[OfflineTeleport] 插件已完成");
    }
    
    public boolean onCommand(final CommandSender sender, final Command cmd, final String label, final String[] args) {
        if (sender instanceof Player) {
            final Player p = (Player)sender;
            if (args.length == 1) {
                Location ploc = null;
                try {
                    final UUID uuid1 = UUID.fromString(args[0]);
                    ploc = Main.ess.getUser(uuid1).getLastLocation();
                }
                catch (IllegalArgumentException ignored) {
                    ploc = Main.ess.getOfflineUser(args[0]).getLastLocation();
                }
                p.teleport(ploc);
                p.sendMessage("§a传送中...");
            }
            if (args.length == 0 || args.length > 1) {
                sender.sendMessage("§c无效的参数用法:/otp [玩家ID]");
            }
        }
        if (!(sender instanceof Player)) {
            sender.sendMessage("§c这个命令只有玩家才可执行.");
        }
        return false;
    }
}
